from django.shortcuts import render

# Create your views here.

def Portfolio(request):
    return render(request,'Portfolio_App/index.html')